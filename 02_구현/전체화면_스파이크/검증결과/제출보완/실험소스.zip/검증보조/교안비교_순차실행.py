"""승인한 교안 비교를 순차 실행한다. 기존 자료/519시도 한도는 늘리지 않는다."""

import asyncio
import importlib.util
import json
import sys
from pathlib import Path

P = Path(__file__).resolve().parents[2]
I = P / "02_구현/전체화면_스파이크"
sys.path.insert(0, str(I))
spec = importlib.util.spec_from_file_location("교안비교", I / "검증/비교실험_실행.py")
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
LEDGER = P / "03_실행데이터/실제연구/호출예산.sqlite3"
EVIDENCE = I / "검증결과/제출보완/교안비교_진행.json"
START_ATTEMPTS = 294
APPROVED_ATTEMPTS = 519
PER_ARM_CAP = 55
TIMEOUT_SECONDS = 360
JOBS = [(q, arm) for q in ("Q4", "Q1", "Q6") for arm in ("baseline", "single")]
# 교안의 역할 소거를 다른 질문에서도 관찰한다. 다음55시도를 확보한 경우만 수행한다.
JOBS.append(("Q6", "no-role"))


def main():
    initial = C.ledger_snapshot(LEDGER)
    began = C.stamp()
    records = []
    frozen = C.identity()
    for question_key, arm in JOBS:
        question = C.QUESTION_PRESETS[question_key]
        expected = C.identity(question=question)
        assert expected["source_hashes"] == frozen["source_hashes"]
        assert expected["runner_sha256"] == frozen["runner_sha256"]
        paths = C.locations("lesson_" + question_key + "_01")
        target = paths["evidence"] / arm / "결과.json"
        before = C.ledger_snapshot(LEDGER)
        remaining = APPROVED_ATTEMPTS - (before["attempt_count"] - START_ATTEMPTS)
        if not target.is_file() and remaining < PER_ARM_CAP:
            records.append({"question_key": question_key, "arm": arm, "not_started": "remaining_less_than_55", "remaining": remaining})
            C.save(EVIDENCE, {"started_at": began, "records": records, "complete": False})
            print("STOP_BUDGET", json.dumps(records[-1], ensure_ascii=False), flush=True)
            return 2
        C.main(["--prepare", "--ledger", str(LEDGER), "--label", paths["evidence"].name, "--question-key", question_key])
        if target.is_file():
            result = json.loads(target.read_text("utf-8"))
            assert result["identity"] == expected and result["config"] == C.ARMS[arm].as_dict()
        else:
            print("START", question_key, arm, "remaining", remaining, flush=True)
            result = asyncio.run(C.run_arm(arm, paths, LEDGER, expected, timeout_seconds=TIMEOUT_SECONDS))
        after = C.ledger_snapshot(LEDGER)
        assert result["accounting_verified"] and result["history_preserved"] and result["source_unchanged"]
        assert C.preserved(initial, after)
        assert after["attempt_count"] - START_ATTEMPTS <= APPROVED_ATTEMPTS
        C.save(paths["evidence"] / "집계.json", C.aggregate(paths))
        record = {key: result.get(key) for key in ("arm", "run_id", "status", "actual_reads", "unique_reads", "actual_model_requests", "runner_issue")}
        record.update(question_key=question_key, question=question, result_path=str(target.relative_to(P)), timeout_seconds=TIMEOUT_SECONDS)
        records.append(record)
        C.save(EVIDENCE, {"records": records, "complete": len(records) == len(JOBS), "attempt_count": after["attempt_count"], "phase_new_attempts": after["attempt_count"] - initial["attempt_count"], "approved_remaining": APPROVED_ATTEMPTS - (after["attempt_count"] - START_ATTEMPTS), "original_unknown_preserved": set(initial["unknown_ids"]) <= set(after["unknown_ids"]), "source_hashes": frozen["source_hashes"], "runner_sha256": frozen["runner_sha256"]})
        print("RESULT", json.dumps(record, ensure_ascii=False), flush=True)
        if result.get("runner_issue"):
            print("STOP_RUNNER_ISSUE", flush=True)
            return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
